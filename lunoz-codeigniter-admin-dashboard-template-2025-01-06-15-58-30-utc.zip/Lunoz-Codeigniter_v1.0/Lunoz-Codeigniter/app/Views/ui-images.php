<?= $this->include("partials/main") ?>

<head>
    <?php echo view("partials/title-meta", array("title" => "Images")) ?>

    <?= $this->include("partials/head-css") ?>

</head>

<body>

    <!-- Begin page -->
    <div class="layout-wrapper">

        <?= $this->include("partials/sidenav") ?>

        <!-- Start Page Content here -->
        <div class="page-content">

            <?= $this->include("partials/topbar") ?>

            <div class="px-3">

                <!-- Start Content-->
                <div class="container-fluid">

                    <?php echo view("partials/page-title", array("title" => "Images", "subtitle" => "Base UI")) ?>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <h4 class="header-title">Images shapes</h4>
                                            <p class="sub-header mb-0">
                                                Add classes to an <code>&lt;img&gt;</code> element to easily style
                                                images in any project.
                                            </p>

                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <div class="mt-3">
                                                        <img src="/images/media/img-1.jpg" alt="image" class="img-fluid rounded" width="200" />
                                                        <p class="mb-0">
                                                            <code>.rounded</code>
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="col-sm-4 text-center">
                                                    <div class="mt-3">
                                                        <img src="/images/users/avatar-6.jpg" alt="image" class="img-fluid rounded-circle" width="120" />
                                                        <p class="mb-0">
                                                            <code>.rounded-circle</code>
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="col-sm-4">
                                                    <div class="mt-3">
                                                        <img src="/images/media/img-3.jpg" alt="image" class="img-fluid img-thumbnail" width="200" />
                                                        <p class="mb-0">
                                                            <code>.img-thumbnail</code>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end col-->

                                        <div class="col-xl-6 mt-3 mt-xl-0">
                                            <h4 class="header-title">Image sizes</h4>
                                            <p class="sub-header mb-0">
                                                Add classes to an <code>&lt;img&gt;</code> element to easily style
                                                images in any project.
                                            </p>

                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <div class="mt-3">
                                                        <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-xs rounded" />
                                                        <p class="mb-0">
                                                            <code>.avatar-xs</code>
                                                        </p>
                                                        <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-sm rounded mt-2" />
                                                        <p class="mb-0">
                                                            <code>.avatar-sm</code>
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="col-sm-3">
                                                    <div class="mt-3">
                                                        <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-md rounded" />
                                                        <p class="mb-0">
                                                            <code>.avatar-md</code>
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="col-sm-3">
                                                    <div class="mt-3">
                                                        <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-lg rounded" />
                                                        <p class="mb-0">
                                                            <code>.avatar-lg</code>
                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="col-sm-3">
                                                    <div class="mt-3">
                                                        <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-xl rounded" />
                                                        <p class="mb-0">
                                                            <code>.avatar-xl</code>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>

                                        </div> <!-- end col -->
                                    </div> <!-- end row -->
                                </div>
                            </div> <!-- end card -->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Border-radius</h4>
                                    <p class="sub-header mb-0">
                                        Add classes to an element to easily round its corners.
                                    </p>

                                    <div class="row">
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded">
                                                <p class="mb-0">
                                                    <code>.rounded</code>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded-top">
                                                <p class="mb-0">
                                                    <code>.rounded-top</code>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded-end" />
                                                <p class="mb-0">
                                                    <code>.rounded-end</code>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded-bottom" />
                                                <p class="mb-0">
                                                    <code>.rounded-bottom</code>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded-start" />
                                                <p class="mb-0">
                                                    <code>.rounded-start</code>
                                                </p>
                                            </div>

                                        </div>
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-3.jpg" alt="image" class="img-fluid avatar-md rounded-circle" />
                                                <p class="mb-0">
                                                    <code>.rounded-circle</code>
                                                </p>
                                            </div>

                                        </div>
                                    </div> <!-- end row-->

                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Sizes</h4>
                                    <p class="sub-header mb-0">
                                        Use the scaling classes for larger or smaller rounded corners
                                    </p>

                                    <div class="row">
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-md rounded-0">
                                                <p class="mb-0">
                                                    <code>.rounded-0</code>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-md rounded-1">
                                                <p class="mb-0">
                                                    <code>.rounded-1</code>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-md rounded-2" />
                                                <p class="mb-0">
                                                    <code>.rounded-2</code>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="col-md col-sm-6">
                                            <div class="mt-3">
                                                <img src="/images/users/avatar-2.jpg" alt="image" class="img-fluid avatar-md rounded-3" />
                                                <p class="mb-0">
                                                    <code>.rounded-3</code>
                                                </p>
                                            </div>
                                        </div>

                                    </div> <!-- end row-->

                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->

            <?= $this->include("partials/footer") ?>

        </div>
        <!-- End Page content -->


    </div>
    <!-- END wrapper -->

    <?= $this->include("partials/footer-scripts") ?>

</body>

</html>
<!-- ========== Left Sidebar ========== -->
<?= $this->include("partials/sidenav") ?>

<!-- @@include('horizontal.html') -->
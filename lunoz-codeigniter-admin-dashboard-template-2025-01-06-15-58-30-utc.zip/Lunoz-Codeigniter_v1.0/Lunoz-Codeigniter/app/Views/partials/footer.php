<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div><script>document.write(new Date().getFullYear())</script> © Lunoz</div>
            </div>
            <div class="col-md-6">
                <div class="d-none d-md-flex gap-4 align-item-center justify-content-md-end">
                    <p class="mb-0">Design & Develop by <a href="https://myrathemes.com/" target="_blank">MyraStudio</a> </p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
<!-- App js -->
<script src="/js/vendor.min.js"></script>
<script src="/js/app.js"></script>
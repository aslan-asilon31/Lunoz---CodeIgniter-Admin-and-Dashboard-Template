<!-- App css -->
<link href="/css/style.min.css" rel="stylesheet" type="text/css">
<link href="/css/icons.min.css" rel="stylesheet" type="text/css">
<script src="/js/config.js"></script>